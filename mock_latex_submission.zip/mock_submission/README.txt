Mock LaTeX Submission Package
=============================
This is a test submission package for ScholarFlow system.

Contents:
- main.tex: Main LaTeX source file with multi-author format
- references.bib: BibTeX references
- figures/: Image resources

Compilation command: pdflatex main && bibtex main && pdflatex main && pdflatex main
